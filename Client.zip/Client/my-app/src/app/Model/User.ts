export class User { //export default class User {
    id: number;
    user_name: string;
    firstName: string;
    lastName: string;
    role: string;
}