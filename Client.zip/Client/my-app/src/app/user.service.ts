import { Injectable } from '@angular/core';
import { User } from './Model/User';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'Basic dGVzdGVyOnRlc3Rlcg=='
  })
}

@Injectable({
  providedIn: 'root'
})


export class UserService {
  
  constructor(
    private http: HttpClient
  ) { }
    
  // Web API Urls
  private GetUsersUrl = 'http://localhost:8080/api/v1/users';
 

  //Get all users from the server
  getUsers (): Observable<User[]> {
    return this.http.get<User[]>(this.GetUsersUrl,httpOptions)
      /*
      .pipe(
        tap(_ => this.log('fetched heroes')),
        catchError(this.handleError('getHeroes', []))
      );
      */
  }

}
