import { Component, OnInit } from '@angular/core';
import { User } from '../Model/User';
import { UserService } from '../user.service';

import { latLng, tileLayer, Map, marker, icon} from 'leaflet';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(
    private userService: UserService
  ) { }

  private users: User[];
  myMarker = marker([38.7573838, -9.1153841], {
    icon: icon({
      iconSize: [ 25, 41 ],
      iconAnchor: [ 13, 41 ],
      iconUrl: 'leaflet/marker-icon.png',
      shadowUrl: 'leaflet/marker-shadow.png'
    })
  });

  private options = {
    layers: [
      tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
      }),
    this.myMarker
    ],
    zoom: 7,
    center: latLng([38.7573838, -9.1153841])
  };
  ngOnInit() {
    this.getUsers();
  }
  
  getUsers(): void {
    this.userService.getUsers()
    .subscribe(users => this.users = users);
  }

  onMapReady(map: Map) {
    map.setView([38.7573838, -9.1153841], 74)

    //var myMarker = marker([38.7573838, -9.1153841]).addTo(map);
    this.myMarker.bindPopup("<b>Hello world!</b><br>I am a popup, and this is ISEL!").openPopup();
  }

}
